import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SugerenciaPage } from './sugerencia';

@NgModule({
  declarations: [
    SugerenciaPage,
  ],
  imports: [
    IonicPageModule.forChild(SugerenciaPage),
  ],
})
export class SugerenciaPageModule {}
